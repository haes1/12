# EyeSwipe — updated

EyeSwipe detects a face with the front camera and uses head pitch as a robust proxy for “look up”. When the threshold is crossed for several consecutive frames, it asks the enabled Accessibility Service to perform an upward swipe.

## Что исправлено

- Добавлен **живой предпросмотр фронтальной камеры**.
- Добавлен **визуальный face box** поверх видео — видно, захватило ли лицо.
- Добавлен режим **«Проверить захват лица»** до запуска фонового режима.
- На экране проверки показываются текущий наклон головы и порог срабатывания.
- Исправлена логика при потере лица: состояние `looking up` теперь сбрасывается.
- Если найдено несколько лиц, выбирается крупнейшее.
- Для защиты от случайных срабатываний нужен короткий стабильный ряд кадров выше порога.
- Кнопки и статусы переработаны в более современный тёмный интерфейс.

## Важно

Это **не pupil/iris gaze tracking**. ML Kit Face Detection предоставляет угол наклона головы (`headEulerAngleX`), поэтому приложение определяет именно движение головы вверх. Для настоящего eye-gaze нужны отдельные landmarks/iris-модель и калибровка.

## Тестирование

1. Разрешите камеру.
2. Нажмите **«Проверить захват лица»**.
3. В окне предпросмотра должно появиться ваше лицо с рамкой.
4. Поднимите голову: показатель наклона должен приблизиться к порогу.
5. Для реального свайпа включите службу EyeSwipe в Android Accessibility и запустите EyeSwipe.

На Android 14+ camera foreground service должен быть запущен при видимом Activity и иметь `FOREGROUND_SERVICE_CAMERA` + разрешение камеры. Это соответствует требованиям Android. 

Accessibility API действительно поддерживает `dispatchGesture`, но сервис обязан объявить `canPerformGestures`. 

## Известные ограничения

- Постоянный анализ камеры расходует батарею.
- Android показывает системный индикатор использования камеры.
- Разные производители могут ограничивать длительную работу фоновых сервисов.
- Перед публикацией в Google Play отдельно проверьте требования к AccessibilityService и назначению приложения.


## Crash/startup hardening
- Camera foreground service is `START_NOT_STICKY` so Android does not silently resurrect a camera service.
- Missing camera permission and foreground-service startup failures are handled without an uncaught exception.
- Camera provider acquisition/binding failures stop the service cleanly.
- GitHub Actions installs a deterministic Gradle 8.7 toolchain instead of relying on a runner-global Gradle version.
- Front camera is declared optional at install time; the app can show a useful error on devices without one.
- Accessibility being disabled while tracking is active is detected when returning from Settings.
